package com.acwd.ui10;
import java.util.ArrayList;
import java.util.Scanner ;
import java.lang.String ;
public class Main {
    public static void main (String args[]){

    }
    /*public String getOption(Scanner input){

    }
    public boolean valid Fraction(String input){

    }
    public Fraction getFraction(Scanner input){

    }*/

}

